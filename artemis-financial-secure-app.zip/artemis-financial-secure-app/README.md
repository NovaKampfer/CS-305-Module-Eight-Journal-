# Artemis Financial Secure App

Spring Boot demo to satisfy CS 305 Project Two requirements:
- `/hash` endpoint that returns a SHA-256 checksum of the `data` query string.
- HTTPS enabled on port **8443** using a self-signed certificate.
- OWASP **Dependency-Check** plugin configured in `pom.xml`.

## Prereqs
- JDK 17+
- Maven 3.9+

## Generate Self-Signed Certificate
```bash
keytool -genkeypair -alias artemis-server \
  -keyalg RSA -keysize 2048 -validity 365 \
  -storetype PKCS12 -keystore keystore.p12 \
  -storepass changeit -keypass changeit \
  -dname "CN=localhost, OU=Engineering, O=Global Rain, L=Seattle, S=WA, C=US"

keytool -exportcert -alias artemis-server -storetype PKCS12 \
  -keystore keystore.p12 -storepass changeit -rfc -file artemis.cer
```
Move `keystore.p12` to `src/main/resources/`.

## Run
```bash
mvn spring-boot:run
```
Open:
```
https://localhost:8443/hash?data=MatthewBaerg-unique-12345
```

## Dependency-Check
```bash
mvn -U org.owasp:dependency-check-maven:check -Dformats=HTML,JSON
# or
mvn clean verify
```

## Notes
- Do **not** commit `keystore.p12` or `*.cer` to public repos.
- Browser will warn on self-signed cert; proceed for local testing only.
