package com.globalrain.artemis;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ChecksumServiceTest {
    @Test
    void sha256_hashesDeterministically() {
        ChecksumService s = new ChecksumService();
        String a = s.sha256("test");
        String b = s.sha256("test");
        assertEquals(a, b);
        assertEquals(64, a.length()); // 256 bits -> 64 hex chars
    }
}
