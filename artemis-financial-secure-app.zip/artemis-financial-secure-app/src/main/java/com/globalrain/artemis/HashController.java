package com.globalrain.artemis;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
public class HashController {
    private final ChecksumService checksumService;

    public HashController(ChecksumService checksumService) {
        this.checksumService = checksumService;
    }

    // Example: https://localhost:8443/hash?data=MatthewBaerg-unique-12345
    @GetMapping("/hash")
    public String hash(@RequestParam(required = false) String data) {
        if (data == null || data.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Query parameter 'data' is required.");
        }
        return checksumService.sha256(data);
    }
}
